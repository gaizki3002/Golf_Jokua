//teklatutik barra-espaziadora irakurri
document.addEventListener('keydown', function (ekintza) {
    if (trex.y == lurra) {
    if(ekintza.keyCode == 32){
        console.log("salto");

        if (nibela.hilda == false)
            saltoaegin();
        else {
            nibela.abiadura = 9;
            nibela.hilda = false;
            hodeia.abiadura = 1;
            kaktus.x = zabalera + 100;
            hodeia.x = zabalera + 100;
            nibela.markadorea = 0;
        }
        }
    }
})

//Canvas
var imgkaktus1, imgdino, imghodei, imglurra;

function IrudiakKargatu(){
    imgdino = new Image();
    imgkaktus1 = new Image();
    imghodei = new Image();
    imglurra = new Image();
    
    imgdino.src = 'img/dino.png';
    imgkaktus1.src = 'img/kaktus1.png';
    imghodei.src = 'img/hodei.png';
    imglurra.src = 'img/lurra.png';
}
var zabalera = 700;
var altuera = 300;

var canvas,ctx;

function hasieratu(){
    canvas = document.getElementById('canvas');
    ctx = canvas.getContext('2d');
    IrudiakKargatu();
}

function borratuCanvas(){
    canvas.width = zabalera;
    canvas.height = altuera;
}

var lurra = 200;
var trex = { y: lurra, vy: 0, grabitatea: 2, salto: 28, vymax: 9, saltoaegiten: false };
var nibela = { abiadura: 9, puntuazioa: 0, hilda: false, markadorea: 0 };
var kaktus = { x: zabalera + 100, y: lurra - 25 };
var hodeia = { x: 400, y: 100, abiadura: 1 };
var lurramugitu = { x: 0, y: 235 };

function marraztuDino(){
    ctx.drawImage(imgdino, 0, 0, 84, 84, 84, trex.y, 50, 50);
}
//------------------------------------------------
function marraztuKaktus() {
    ctx.drawImage(imgkaktus1, 0, 0, 46, 96, kaktus.x, kaktus.y, 46, 96);
}

function logikaKaktus() {
    if (kaktus.x < -100) {
        kaktus.x = zabalera + 100;
        nibela.markadorea++;
    }
    else {
        kaktus.x -= nibela.abiadura;
    }
}
//------------------------------------------------
function marraztuHodeia() {
    ctx.drawImage(imghodei, 0, 0, 92, 26, hodeia.x, hodeia.y, 92, 26);
}
function logikaHodeia() {
    if (hodeia.x < -100) {
        hodeia.x = zabalera + 100;
    }
    else {
        hodeia.x -= hodeia.abiadura;
    }
}
//------------------------------------------------
function marraztuLurra() {
    ctx.drawImage(imglurra, lurramugitu.x, 0, 700, 30, 0, lurramugitu.y, 700, 65);
}

function logikaLurra() {
    if (lurramugitu.x > 700) {
        lurramugitu.x = 0;
    }
    else {
        lurramugitu.x += nibela.abiadura;
    }
}
//------------------------------------------------
function kolisioa() {
    if (kaktus.x >= 100 && kaktus.x <= 140) {
        if (trex.y >= lurra - 100) {
            nibela.hilda = true;
            nibela.abiadura = 0;
            hodeia.abiadura = 0;
        }
    }
}
//------------------------------------------------
function saltoaegin() {
    trex.saltoaegiten = true;
    trex.vy = trex.salto;
}
function grabitatea(){
    if (trex.saltoaegiten == true) {

        if (trex.y > lurra) {
            trex.saltoegiten = false;
            trex.vy = 0;
            trex.y = lurra;
        }
        else {
            trex.vy -= trex.grabitatea;
            trex.y -= trex.vy;
        }
    }
}
//------------------------------------------------
function puntuazioa() {
    ctx.font = "35px impact";
    ctx.fillStyle = '#555555'
    ctx.fillText(`${nibela.markadorea}`, 600, 50);

    if (nibela.hilda == true) {
        ctx.font = "60px impact";
        ctx.fillText(`GAME OVER`, 240, 150);
        ctx.font = "30px impact";
        ctx.fillText(`Sakatu espazio tekla berriro hasteko`, 200, 200);
    }
}

//-------------------------------------------------------------------------------------------
//Bukle printzipala zenbat aldiz ejekutatuko den
var FPS = 60;

setInterval(function(){
    printzipala();
}, 1000 / FPS);

//funtzio guztiak izendatu behar dira
function printzipala(){
    borratuCanvas();
    marraztuDino();
    grabitatea();
    kolisioa();
    marraztuKaktus();
    logikaKaktus();
    marraztuHodeia();
    logikaHodeia();
    marraztuLurra();
    logikaLurra();
    puntuazioa();
    
}
